import { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import HomePage from "./components/HomePage";
import FeaturesSection from "./components/FeaturesSection";
import Footer from "./components/Footer";

function App() {
  // Fix: Wrap multiple components in a Fragment
  const Home = () => {
    return (
      <>
        <HomePage />
        <FeaturesSection />
      </>
    );
  };

  return (
    <div className="min-h-screen bg-[#fdfcf9]">
      <Header />

      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          {/* You can add more routes here as your project grows */}
        </Routes>
      </main>
      <Footer/>
    </div>
  );
}

export default App;